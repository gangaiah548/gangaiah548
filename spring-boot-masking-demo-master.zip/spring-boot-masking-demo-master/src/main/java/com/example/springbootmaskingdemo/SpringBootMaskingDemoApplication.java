package com.example.springbootmaskingdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMaskingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMaskingDemoApplication.class, args);
	}

}
